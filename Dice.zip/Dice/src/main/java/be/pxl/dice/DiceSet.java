package be.pxl.dice;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.ArrayList;
import java.util.List;
public class DiceSet implements Rollable{
    public static final int MIN_DIES = 2;
    @JsonProperty("maxNumber")
    private int sidesOnEachDie;
    @JsonProperty("numberOfDice")
    private int numberOfDice;
    private Die[] diceSet;

    public DiceSet(){

    }

    public DiceSet(int numberOfDice, int sidesOnEachDie){
        setNumberOfDice(numberOfDice);
        diceSet = new Die[numberOfDice];
        this.sidesOnEachDie = sidesOnEachDie;

        for(int i = 0; i < diceSet.length; i++){
            diceSet[i] = new Die(sidesOnEachDie);
        }
    }

    public void setNumberOfDice(int numberOfDice) {
        if(numberOfDice < MIN_DIES){
            throw new IllegalArgumentException("Number of dice should be more or equal to " + MIN_DIES);
        }
        this.numberOfDice = numberOfDice;
    }

    public Die[] getDiceSet() {
        return diceSet;
    }

    public int getSidesOnEachDie() {
        return sidesOnEachDie;
    }

    public int getNumberOfDice() {
        return numberOfDice;
    }

    public String getDescriptor(){
        return String.format("%dd%d", diceSet.length, sidesOnEachDie);
    }

    public int sum(){
        int sumOfTheCurrentValueOfTheDice = 0;
        for(int i = 0; i < diceSet.length; i++){
            sumOfTheCurrentValueOfTheDice += diceSet[i].getCurrentValue();
        }
        return sumOfTheCurrentValueOfTheDice;
    }
    @Override
    public void roll() {
        for(Die die : diceSet){
            die.roll();
        }
    }

    public void rollIndividual(int i){
        if(i > diceSet.length - 1 || i < 0){
            throw new IndexOutOfBoundsException();
        }
        diceSet[i].roll();
    }

    public int getIndividual(int i){
        if(i > diceSet.length - 1 || i < 0){
            throw new IndexOutOfBoundsException();
        }
        return diceSet[i].getCurrentValue();
    }

    public void setIndividual(int i, int value){
        if(i > diceSet.length - 1 || i < 0){
            throw new IndexOutOfBoundsException();
        }
        diceSet[i].setCurrentValue(value);
    }

    public List<Integer> values(){
        ArrayList<Integer> currentValues = new ArrayList<>();
        for(int i = 0; i < diceSet.length; i++){
            currentValues.add(diceSet[i].getCurrentValue());
        }
        return currentValues;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        for(Die die : diceSet){
            builder.append(die.toString());
        }
        return builder.toString();
    }
}
