package be.pxl.dice;

import be.pxl.dice.exceptions.InvalidDieException;

import java.util.Random;

public class Die implements Rollable {
    public static final int MIN_SIDES = 4;
    public static final String SIX_SIDED_DIE_EMOJI = "\uD83C\uDFB2";
    private final int sides;
    private int currentValue;
    private final Random random = new Random();

    public Die(int sides) {
        if(sides < MIN_SIDES){
            throw new IllegalArgumentException("The minimum sides should be " + MIN_SIDES);
        }
        this.sides = sides;
    }

    public int getSides() {
        return sides;
    }

    public int getCurrentValue() {
        return currentValue;
    }

    public void setCurrentValue(int currentValue) {
        if(currentValue <= 0 || currentValue > sides){
            throw new InvalidDieException("The current value should be between 1 and " + this.sides);
        }
        this.currentValue = currentValue;
    }

    @Override
    public void roll() {
        currentValue = random.nextInt(1, sides + 1);
    }

    @Override
    public String toString() {
        return String.format("[%d]", this.currentValue);
    }
}
