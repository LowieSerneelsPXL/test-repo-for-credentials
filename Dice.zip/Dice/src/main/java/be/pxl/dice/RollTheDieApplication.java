package be.pxl.dice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RollTheDieApplication {

	public static void main(String[] args) {
		SpringApplication.run(RollTheDieApplication.class, args);
	}

}
