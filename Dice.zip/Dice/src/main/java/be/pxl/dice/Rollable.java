package be.pxl.dice;

public interface Rollable {
    void roll();
}
