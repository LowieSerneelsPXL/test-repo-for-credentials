package be.pxl.dice.controller;

import be.pxl.dice.DiceSet;
import be.pxl.dice.service.DiceSetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class DiceSetController {
    DiceSetService diceSetService;

    public DiceSetController(DiceSetService diceSetService) {
        this.diceSetService = diceSetService;
    }

    @PostMapping("/diceset")
    public ResponseEntity<String> createDiceSet(@RequestBody DiceSet request) {
        try {
            DiceSet diceSet = new DiceSet(request.getNumberOfDice(), request.getSidesOnEachDie());
            this.diceSetService.setDiceSet(diceSet);
            return ResponseEntity.status(HttpStatus.CREATED).body("Dice set created successfully.");
        } catch (IllegalArgumentException ex) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Error: " + ex.getMessage());
        }
    }

    @GetMapping("/diceset")
    public ResponseEntity<List<Integer>> getCurrentDiceSet(){
        return new ResponseEntity<>(this.diceSetService.getDiceSet().values(), HttpStatus.OK);
    }

    @PostMapping("/diceset/roll")
    public ResponseEntity<List<Integer>> rollDice(@RequestParam(required = false) Integer dice) {
        if (dice == null) {
            this.diceSetService.getDiceSet().roll();
        } else {
            this.diceSetService.getDiceSet().rollIndividual(dice);
        }
        return new ResponseEntity<>(this.diceSetService.getDiceSet().values(), HttpStatus.OK);
    }
}
