package be.pxl.dice.exceptions;

public class InvalidDieException extends RuntimeException{

    public InvalidDieException(String message){
        super(message);
    }
}
