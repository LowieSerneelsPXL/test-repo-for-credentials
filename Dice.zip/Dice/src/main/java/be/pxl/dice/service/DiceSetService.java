package be.pxl.dice.service;

import be.pxl.dice.DiceSet;
import org.springframework.stereotype.Service;

@Service
public class DiceSetService {
    private DiceSet diceSet;

    public DiceSetService(){

    }

    public void setDiceSet(DiceSet diceSet) {
        this.diceSet = diceSet;
    }

    public DiceSet getDiceSet() {
        return diceSet;
    }
}
