package be.pxl.dice;
import be.pxl.dice.exceptions.InvalidDieException;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class RollTheDieApplicationTests {
	private Die die;
	private DiceSet diceSet;

	@BeforeEach
	public void init(){
		this.die = new Die(4);
		this.die.setCurrentValue(2);
		this.diceSet = new DiceSet(2, 4);
	}

	@Test
	public void createADieWithValidParameters(){
		assertEquals(4, die.getSides());
	}

	@Test
	public void createADieLessThanFourSidesShouldThrowAnException(){
		IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
			new Die(2);
		});
		assertEquals("The minimum sides should be 4", exception.getMessage());
	}

	@Test
	public void settingAValidCurrentValueForTheDie(){
		die.setCurrentValue(4);
		assertEquals(4, die.getCurrentValue());
	}

	@Test
	public void setAnInvalidCurrentValueShouldThrowInvalidDieException(){
		InvalidDieException exception = assertThrows(InvalidDieException.class, () -> {
			die.setCurrentValue(7);
		});
		assertEquals("The current value should be between 1 and 4", exception.getMessage());
	}

	@Test
	public void toStringShouldReturnTheCurrentValueOfTheDie(){
		String valueOfTheToString = this.die.toString();
		assertEquals("[2]", valueOfTheToString);
	}

	@Test
	public void dieShouldRollWithARandomCurrentValueLessOrEqualTheSides(){
		this.die.roll();
		assertNotEquals(5, die.getCurrentValue());
	}

	@Test
	public void DieAndDiceSetClassesShouldImplementRollableInterface(){
		assertInstanceOf(Rollable.class, die);
		assertInstanceOf(Rollable.class, diceSet);
	}

	@Test
	public void DiceSetShouldBeCreatedWithValidParameters(){
		assertEquals(2, diceSet.getNumberOfDice());
		assertEquals(4, diceSet.getSidesOnEachDie());
	}

	@Test
	public void numberOfSidesLessThanTwoShouldThrowException(){
		IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
			diceSet.setNumberOfDice(1);
		});
		assertEquals("Number of dice should be more or equal to 2", exception.getMessage());
	}

	@Test
	public void getDescriptorMethodShouldReturnAValidString(){
		assertEquals("2d4", diceSet.getDescriptor());
	}

	@Test
	public void rollMethodShouldRollAllTheDiceInTheSet(){
		diceSet.roll();
		for(int currentValue : diceSet.values()){
			assertNotEquals(0, currentValue);
		}
	}

	@Test
	public void rollingAnIndividualDie(){
		diceSet.rollIndividual(1);
		assertNotEquals(0, diceSet.getDiceSet()[1]);
	}

	@Test
	public void invalidIndexShouldThrowException(){
		IndexOutOfBoundsException exception = assertThrows(IndexOutOfBoundsException.class, () -> {
			diceSet.rollIndividual(10);
		});
	}

	@Test
	public void ReturnAllTheCurrentValuesOfTheDice(){
		diceSet.setIndividual(0, 1);
		diceSet.setIndividual(1, 2);
		List<Integer> expectedValues = new ArrayList<>();
		expectedValues.add(1);
		expectedValues.add(2);
		assertEquals(expectedValues, diceSet.values());
	}
}
